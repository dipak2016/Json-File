//
//  ViewController.h
//  EmailSend
//
//  Created by Tops on 12/23/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<NSURLConnectionDelegate>
@property (weak, nonatomic) IBOutlet UITextField *txt_from;
@property (weak, nonatomic) IBOutlet UITextField *txt_pass;
@property (weak, nonatomic) IBOutlet UITextField *txt_to;
@property (weak, nonatomic) IBOutlet UITextField *txt_sub;
@property (weak, nonatomic) IBOutlet UITextField *txt_body;
- (IBAction)btn_action:(id)sender;


@end

