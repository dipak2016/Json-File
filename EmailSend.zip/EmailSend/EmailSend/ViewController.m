//
//  ViewController.m
//  EmailSend
//
//  Created by Tops on 12/23/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize txt_from,txt_body,txt_pass,txt_sub,txt_to;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
    
}
- (IBAction)btn_action:(id)sender
{
    NSString *st_format=[NSString stringWithFormat:@"http://ios8192014.somee.com/webservice.asmx/MailSend?emailFrom=%@&password=%@&emailTo=%@&subject=%@&body=%@",txt_from.text,txt_pass.text,txt_to.text,txt_sub.text,txt_body.text];

    NSURL *url=[NSURL URLWithString:st_format];
    NSURLRequest *req=[NSURLRequest requestWithURL:url];
    NSURLConnection *con=[NSURLConnection connectionWithRequest:req delegate:self];
    if (con)
    {
        
    }
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    NSLog(@"response");
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"%@",[error description]);
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSLog(@"data");
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSLog(@"finish");
}
@end
