//
//  ConnectionClass.h
//  JsonWebService
//
//  Created by Tops on 11/24/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol ConnectionProtocol <NSObject>
@required

@optional
-(void)GetData:(NSArray *)Arr_json Flag:(NSString *)st_flag;
@end

@interface ConnectionClass : NSObject<ConnectionProtocol,NSURLConnectionDelegate>
{
    NSMutableData *datamute;
    NSString *st_global_flag;
}
-(void)ConnectWithURL:(NSString *)st_url Flag:(NSString *)st_flag;
@property(retain,nonatomic)id delegate;
@end
