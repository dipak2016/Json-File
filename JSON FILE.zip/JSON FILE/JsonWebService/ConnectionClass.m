//
//  ConnectionClass.m
//  JsonWebService
//
//  Created by Tops on 11/24/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import "ConnectionClass.h"

@implementation ConnectionClass
@synthesize delegate;
-(void)ConnectWithURL:(NSString *)st_url Flag:(NSString *)st_flag
{
    st_global_flag=st_flag;
    NSURL *url;
    NSMutableURLRequest *req;
    NSURLConnection *con;
    if ([st_flag isEqual:@"insert"])
    {
        NSString *url_format=[[[st_url componentsSeparatedByString:@"?"]objectAtIndex:0]stringByAppendingString:@"?"];
        
        NSString *data_format=[[st_url componentsSeparatedByString:@"?"]objectAtIndex:1];
        
        url=[NSURL URLWithString:url_format];
        
        req=[NSMutableURLRequest requestWithURL:url];
        [req setHTTPBody:[data_format dataUsingEncoding:NSUTF8StringEncoding]];
        [req setHTTPMethod:@"POST"];
        
        con=[NSURLConnection connectionWithRequest:req delegate:self];
        if (con)
        {
            datamute=[[NSMutableData alloc]init];
        }
    }
    else
    {
    url=[NSURL URLWithString:st_url];
    req=[NSMutableURLRequest requestWithURL:url];
    con=[NSURLConnection connectionWithRequest:req delegate:self];
        if (con)
        {
            datamute=[[NSMutableData alloc]init];
        }
    }
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView *alrt=[[UIAlertView alloc]initWithTitle:@"Error" message:[error description] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    [alrt show];
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    datamute.length=0;
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [datamute appendData:data];
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    if ([delegate respondsToSelector:@selector(GetData:Flag:)])
    {
        if ([st_global_flag isEqual:@"insert"]||[st_global_flag isEqual:@"login"])
        {
            NSString *datast=[[NSString alloc]initWithData:datamute encoding:NSUTF8StringEncoding];
            NSArray *arrst=[NSArray arrayWithObject:datast];
            [delegate GetData:arrst Flag:st_global_flag];
        }
        else
        {
        NSArray *arr=[NSJSONSerialization JSONObjectWithData:datamute options:kNilOptions error:nil];
        
        [delegate GetData:arr Flag:st_global_flag];
        }
    }
}
@end
