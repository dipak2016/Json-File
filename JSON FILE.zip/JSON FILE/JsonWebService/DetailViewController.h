//
//  DetailViewController.h
//  JsonWebService
//
//  Created by Tops on 11/26/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
@interface DetailViewController : UIViewController<ConnectionProtocol>
{
    ConnectionClass *con;
    NSArray *arr_global;
}
@property (weak, nonatomic) IBOutlet UILabel *lbl_f_nm;
@property (weak, nonatomic) IBOutlet UILabel *lbl_l_nm;
@property (weak, nonatomic) IBOutlet UILabel *lbl_st;
@property (weak, nonatomic) IBOutlet UILabel *lbl_ct;
@property (weak, nonatomic) IBOutlet UILabel *lbl_unm;
@property (weak, nonatomic) IBOutlet UIImageView *img_vw;
- (IBAction)btn_edit:(id)sender;
@property(retain,nonatomic)NSString *st_get_id;
@end
