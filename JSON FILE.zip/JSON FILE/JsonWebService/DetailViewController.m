//
//  DetailViewController.m
//  JsonWebService
//
//  Created by Tops on 11/26/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController
@synthesize st_get_id,lbl_ct,lbl_f_nm,lbl_l_nm,lbl_st,lbl_unm,img_vw;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    arr_global=[[NSArray alloc]init];
    
    con=[[ConnectionClass alloc]init];
    con.delegate=self;
    NSString *st_format=[NSString stringWithFormat:@"http://ios8192014.somee.com/webservice.asmx/JsonCrud5GetUserDataByID?u_id=%@",st_get_id];
    [con ConnectWithURL:st_format Flag:@"detail"];
}
-(void)GetData:(NSArray *)Arr_json Flag:(NSString *)st_flag
{
    if ([st_flag isEqual:@"detail"])
    {
        NSLog(@"%@",Arr_json);
        if (Arr_json.count>0)
        {
        lbl_f_nm.text=[[Arr_json objectAtIndex:0]objectForKey:@"u_fnm"];
        lbl_l_nm.text=[[Arr_json objectAtIndex:0]objectForKey:@"u_lnm"];
        lbl_st.text=[[Arr_json objectAtIndex:0]objectForKey:@"state_nm"];
        lbl_ct.text=[[Arr_json objectAtIndex:0]objectForKey:@"city_nm"];
        lbl_unm.text=[[Arr_json objectAtIndex:0]objectForKey:@"u_unm"];
          NSURL *url=[[NSURL alloc]initWithString:[[Arr_json objectAtIndex:0]objectForKey:@"u_photo"]];
            NSData *data=[NSData dataWithContentsOfURL:url];
            img_vw.image=[UIImage imageWithData:data];
            arr_global=Arr_json;
            arr_global=[arr_global arrayByAddingObject:img_vw.image];
            
        }
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btn_edit:(id)sender
{
    ViewController *vc=[[self.navigationController viewControllers]objectAtIndex:0];
    vc.arr_vw_one=arr_global;
    [self.navigationController popToViewController:vc animated:YES];
    
}
@end
