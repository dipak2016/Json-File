//
//  ViewController.h
//  JsonWebService
//
//  Created by Tops on 11/24/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ConnectionClass.h"
@interface ViewController : UIViewController<UIPickerViewDataSource,UIPickerViewDelegate,ConnectionProtocol,UITextFieldDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    UIPickerView *pkr_state;
    UIPickerView *pkr_city;
    NSArray *arr_st;
    NSArray *arr_ct;
    ConnectionClass *con;
    NSString *store_id;
}
@property (weak, nonatomic) IBOutlet UITextField *txt_f_nm;
@property (weak, nonatomic) IBOutlet UITextField *txt_l_nm;
@property (weak, nonatomic) IBOutlet UITextField *txt_state;
@property (weak, nonatomic) IBOutlet UITextField *txt_city;
@property (weak, nonatomic) IBOutlet UITextField *txt_u_nm;
@property (weak, nonatomic) IBOutlet UITextField *txt_u_pass;
@property (weak, nonatomic) IBOutlet UIImageView *img_vw;
@property (retain, nonatomic) NSArray *arr_vw_one;
- (IBAction)btn_upload:(id)sender;
- (IBAction)btn_submit:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btn_out;



@end

