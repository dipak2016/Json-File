//
//  ViewController.m
//  JsonWebService
//
//  Created by Tops on 11/24/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize txt_f_nm,txt_l_nm,txt_state,txt_city,txt_u_nm,txt_u_pass,img_vw,arr_vw_one,btn_out;
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    con=[[ConnectionClass alloc]init];
    con.delegate=self;
    [con ConnectWithURL:@"http://ios8192014.somee.com/webservice.asmx/JsonCrud1GetAllStates" Flag:@"state"];
    
    pkr_state=[[UIPickerView alloc]init];
    pkr_state.dataSource=self;
    pkr_state.delegate=self;
    [txt_state setInputView:pkr_state];
    arr_st=[[NSArray alloc]init];
    
    pkr_city=[[UIPickerView alloc]init];
    pkr_city.dataSource=self;
    pkr_city.delegate=self;    
    [txt_city setInputView:pkr_city];
    
    txt_city.delegate=self;
    arr_ct=[[NSArray alloc]init];
}
-(void)viewWillAppear:(BOOL)animated
{
    if (arr_vw_one.count>0)
    {
        NSLog(@"%@",arr_vw_one);
        txt_f_nm.text=[[arr_vw_one objectAtIndex:0]objectForKey:@"u_fnm"];
        txt_l_nm.text=[[arr_vw_one objectAtIndex:0]objectForKey:@"u_lnm"];
        txt_state.text=[[arr_vw_one objectAtIndex:0]objectForKey:@"state_nm"];
        txt_city.text=[[arr_vw_one objectAtIndex:0]objectForKey:@"city_nm"];
        txt_u_nm.text=[[arr_vw_one objectAtIndex:0]objectForKey:@"u_unm"];
        txt_u_pass.text=[[arr_vw_one objectAtIndex:0]objectForKey:@"u_pass"];
        img_vw.image=[arr_vw_one objectAtIndex:1];
        store_id=[[arr_vw_one objectAtIndex:0]objectForKey:@"u_id"];
        [btn_out setTitle:@"UPDATE" forState:UIControlStateNormal];
        arr_vw_one=nil;
    }
}
-(void)GetData:(NSArray *)Arr_json Flag:(NSString *)st_flag
{
    if ([st_flag isEqual:@"state"])
    {
        arr_st=Arr_json;
        //NSLog(@"%@",Arr_json);
        [pkr_state reloadAllComponents];
    }
    if ([st_flag isEqual:@"city"])
    {
        arr_ct=Arr_json;
        //NSLog(@"%@",Arr_json);
        [pkr_city reloadAllComponents];
    }
    if ([st_flag isEqual:@"insert"])
    {
        UIAlertView *alrt=[[UIAlertView alloc]initWithTitle:@"Alert" message:[Arr_json objectAtIndex:0] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alrt show];
    }
}
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if ([textField isEqual:txt_city])
    {
        if (txt_state.text.length>0)
        {
            NSArray *arr_nm=[NSArray arrayWithArray:[arr_st valueForKey:@"state_nm"]];
            NSInteger index=[arr_nm indexOfObject:txt_state.text];
            NSString *st_id=[[arr_st objectAtIndex:index]objectForKey:@"state_id"];
            NSString *url=[NSString stringWithFormat:@"http://ios8192014.somee.com/webservice.asmx/JsonCrud2GetCityByState?state_id=%@",st_id];
            [con ConnectWithURL:url Flag:@"city"];
        }
    }
}
// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    int index;
    if (pickerView==pkr_state)
    {
        index=(int)arr_st.count;
    }
    else if (pickerView==pkr_city)
    {
        index=(int)arr_ct.count;
    }
    return index;
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    NSString *index=@"";
    if (pickerView==pkr_state)
    {
        index=[[arr_st objectAtIndex:row]objectForKey:@"state_nm"];
    }
    else if (pickerView==pkr_city)
    {
        index=[[arr_ct objectAtIndex:row]objectForKey:@"city_nm"];
    }
    return index;
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if (pickerView==pkr_state)
    {
        txt_state.text=[[arr_st objectAtIndex:row]objectForKey:@"state_nm"];
    }
    else if (pickerView==pkr_city)
    {
        txt_city.text=[[arr_ct objectAtIndex:row]objectForKey:@"city_nm"];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btn_upload:(id)sender
{
    UIImagePickerController *img=[[UIImagePickerController alloc]init];
    img.delegate=self;
    img.sourceType=UIImagePickerControllerSourceTypeSavedPhotosAlbum;
    [self presentViewController:img animated:YES completion:nil];
    
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [self dismissViewControllerAnimated:YES completion:nil];
    UIImage *img=info[UIImagePickerControllerOriginalImage];
    img_vw.image=img;
}
- (NSString *)imageToNSString:(UIImage *)image
{
    /*
     NSData *data = UIImagePNGRepresentation(image);
     
     return [data base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
     */
    NSData* data = UIImageJPEGRepresentation(image, 1.0f);
    return [data base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
}

- (IBAction)btn_submit:(id)sender
{
    NSString *submit=@"";
    NSArray *arr_nm=[NSArray arrayWithArray:[arr_st valueForKey:@"state_nm"]];
    NSInteger index=[arr_nm indexOfObject:txt_state.text];
    NSString *st_id=[[arr_st objectAtIndex:index]objectForKey:@"state_id"];
    
    NSArray *arr_ct_get=[NSArray arrayWithArray:[arr_ct valueForKey:@"city_nm"]];
    NSInteger indexct=[arr_ct_get indexOfObject:txt_city.text];
    NSString *ct_id=[[arr_ct objectAtIndex:indexct]objectForKey:@"city_id"];
    if ([btn_out.titleLabel.text isEqual:@"Submit"])
    {
         submit=[NSString stringWithFormat:@"http://ios8192014.somee.com/webservice.asmx/JsonCrud3InsertUserData?txt_fnm=%@&txt_lnm=%@&u_st=%@&u_ct=%@&u_photo=%@&u_unm=%@&u_pass=%@",txt_f_nm.text,txt_l_nm.text,st_id,ct_id,[self imageToNSString:img_vw.image],txt_u_nm.text,txt_u_pass.text];
    }
    if ([btn_out.titleLabel.text isEqual:@"UPDATE"])
    {
         submit=[NSString stringWithFormat:@"http://ios8192014.somee.com/webservice.asmx/JsonCrud6UpdateUserData?txt_fnm=%@&txt_lnm=%@&u_st=%@&u_ct=%@&u_photo=%@&u_unm=%@&u_pass=%@&u_id=%@",txt_f_nm.text,txt_l_nm.text,st_id,ct_id,[self imageToNSString:img_vw.image],txt_u_nm.text,txt_u_pass.text,store_id];
    }
    [btn_out setTitle:@"Submit" forState:UIControlStateNormal];

    
    [con ConnectWithURL:submit Flag:@"insert"];
    
}
@end
