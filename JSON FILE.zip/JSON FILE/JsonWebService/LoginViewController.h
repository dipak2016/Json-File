//
//  LoginViewController.h
//  JsonWebService
//
//  Created by Tops on 11/26/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailViewController.h"
@interface LoginViewController : UIViewController<ConnectionProtocol>
{
    ConnectionClass *con;
}
@property (weak, nonatomic) IBOutlet UITextField *txt_u_nm;
@property (weak, nonatomic) IBOutlet UITextField *txt_u_pass;
- (IBAction)btn_login:(id)sender;

@end
