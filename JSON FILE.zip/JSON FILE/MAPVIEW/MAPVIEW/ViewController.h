//
//  ViewController.h
//  MAPVIEW
//
//  Created by tops on 3/5/16.
//  Copyright (c) 2016 tops. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
@interface ViewController : UIViewController
- (IBAction)GO_ACTION:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *TXT_OUT;
@property (weak, nonatomic) IBOutlet UIButton *MAP_VIEW;
@property (weak, nonatomic) IBOutlet MKMapView *mp_vw;


@end

