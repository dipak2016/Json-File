//
//  ViewController.m
//  MAPVIEW
//
//  Created by tops on 3/5/16.
//  Copyright (c) 2016 tops. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize TXT_OUT,MAP_VIEW,mp_vw;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)GO_ACTION:(id)sender
{
    NSString *st_format=[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/geocode/json?address=%@",[TXT_OUT.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    NSURL *url=[NSURL URLWithString:st_format];
    NSData *data=[NSData dataWithContentsOfURL:url];
    NSDictionary *dict=[NSJSONSerialization JSONObjectWithData: data options: kNilOptions error:Nil];
    NSLog(@"lat:%@",[[[[[dict objectForKey:@"result"]objectAtIndex:0]objectForKey:@"geometry"]objectForKey:@"location"]objectForKey:@"lat"]);
    NSLog(@"lng:%@",[[[[[dict objectForKey:@"result"]objectAtIndex:0]objectForKey:@"geometry"]objectForKey:@"location"]objectForKey:@"lng"]);
    CLLocationCoordinate2D loc;
    loc.latitude=[[[[[[dict objectForKey:@"results"]objectAtIndex:0]objectForKey:@"geometry"]objectForKey:@"location"]objectForKey:@"lat"]floatValue];
    loc.longitude=[[[[[[dict objectForKey:@"results"]objectAtIndex:0]objectForKey:@"geometry"]objectForKey:@"location"]objectForKey:@"lng"]floatValue];
    MKCoordinateRegion regin;
    regin.center=loc;
    regin.span.latitudeDelta=0.1;
    regin.span.longitudeDelta=0.1;
    
    MKPointAnnotation *point=[[MKPointAnnotation alloc]init];
    [point setCoordinate:loc];
    
    [mp_vw addAnnotation:point];
    [mp_vw setRegion:regin];
    [mp_vw regionThatFits:regin];
    
}
@end
