//
//  ViewController.h
//  imdb movie
//
//  Created by tops on 3/28/16.
//  Copyright (c) 2016 tops. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSArray *arr;
}

@property (weak, nonatomic) IBOutlet UIImageView *img_vw;
@property (weak, nonatomic) IBOutlet UITableView *tbl_vw;



@end

