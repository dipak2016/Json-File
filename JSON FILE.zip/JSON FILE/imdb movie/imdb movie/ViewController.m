//
//  ViewController.m
//  imdb movie
//
//  Created by tops on 3/28/16.
//  Copyright (c) 2016 tops. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize img_vw,tbl_vw;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    tbl_vw.dataSource=self;
    tbl_vw.delegate=self;
    
    NSString *st_format=[NSString stringWithFormat:@"http://www.omdbapi.com/?i=tt4324274&plot=short&r=json"];
    NSURL *url=[NSURL URLWithString:st_format];
    NSData *data=[NSData dataWithContentsOfURL:url];
    NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
    arr=[dict allValues];
    NSLog(@"%@",dict);
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=nil;
    cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"];
    cell.textLabel.text=[arr objectAtIndex:indexPath.row];
    NSDictionary *dict=[arr objectAtIndex:indexPath.row];
    NSLog(@"%@",[dict allKeys]);

       return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
