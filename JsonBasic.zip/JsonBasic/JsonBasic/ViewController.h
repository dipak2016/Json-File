//
//  ViewController.h
//  JsonBasic
//
//  Created by Tops on 12/14/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *lbl_nm;
@property (weak, nonatomic) IBOutlet UIWebView *web_vw;


@end

