//
//  ViewController.m
//  JsonBasic
//
//  Created by Tops on 12/14/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize lbl_nm,web_vw;
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSURL *url=[NSURL URLWithString:@"http://jsonview.com/example.json"];
    NSData *data=[NSData dataWithContentsOfURL:url];
    
    NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
    /*
    for (id ids in dict)
    {
        NSLog(@"KEY:%@ VALUE:%@",ids,[dict objectForKey:ids]);
    }
    */
    
    NSLog(@"%@",[[[dict objectForKey:@"anobject"]objectForKey:@"anarray"]objectAtIndex:2]);
    
    
    
    lbl_nm.text=[dict objectForKey:@"japanese"];
    [web_vw loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[dict objectForKey:@"link"]]]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
