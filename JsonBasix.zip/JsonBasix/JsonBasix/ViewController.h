//
//  ViewController.h
//  JsonBasix
//
//  Created by Tops on 2/1/16.
//  Copyright (c) 2016 Tops. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MYCollectionViewController.h"
@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSArray *arr_get;
}
@property (weak, nonatomic) IBOutlet UITableView *tbl_vw;
@end

