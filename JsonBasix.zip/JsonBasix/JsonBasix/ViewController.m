//
//  ViewController.m
//  JsonBasix
//
//  Created by Tops on 2/1/16.
//  Copyright (c) 2016 Tops. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize tbl_vw;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    tbl_vw.dataSource=self;
    tbl_vw.delegate=self;
    NSURL *url=[NSURL URLWithString:@"https://raw.githubusercontent.com/jheer/dream-stream/master/data/output/ed-hopefeathers-terms.json"];
    NSData *data=[NSData dataWithContentsOfURL:url];
    arr_get=[[NSArray alloc]initWithArray:[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil]];
    for (int i=0; i<arr_get.count; i++)
    {
        NSLog(@"Index:%d Valute:%@",i,[arr_get objectAtIndex:i]);
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arr_get.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=nil;
    cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"];
    cell.textLabel.text=[[arr_get objectAtIndex:indexPath.row]objectForKey:@"query"];
    int count=(int)[[[arr_get objectAtIndex:indexPath.row]objectForKey:@"image"]count];
    cell.detailTextLabel.text=[NSString stringWithFormat:@"PHOTOS : %d",count];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPat
{
    MYCollectionViewController *mycollect=[self.storyboard instantiateViewControllerWithIdentifier:@"MYCollectionViewController"];
    mycollect.arr_img=[[arr_get objectAtIndex:indexPat.row]objectForKey:@"image"];
    [self.navigationController pushViewController:mycollect animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
