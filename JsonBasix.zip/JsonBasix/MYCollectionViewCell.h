//
//  MYCollectionViewCell.h
//  JsonBasix
//
//  Created by Tops on 2/1/16.
//  Copyright (c) 2016 Tops. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MYCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *img_vw;

@end
