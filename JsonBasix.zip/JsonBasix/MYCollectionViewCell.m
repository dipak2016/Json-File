//
//  MYCollectionViewCell.m
//  JsonBasix
//
//  Created by Tops on 2/1/16.
//  Copyright (c) 2016 Tops. All rights reserved.
//

#import "MYCollectionViewCell.h"

@implementation MYCollectionViewCell
@synthesize img_vw;
@end
