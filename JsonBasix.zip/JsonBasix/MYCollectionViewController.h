//
//  MYCollectionViewController.h
//  JsonBasix
//
//  Created by Tops on 2/1/16.
//  Copyright (c) 2016 Tops. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MYCollectionViewCell.h"
@interface MYCollectionViewController : UICollectionViewController
@property(retain,nonatomic)NSArray *arr_img;
@end
