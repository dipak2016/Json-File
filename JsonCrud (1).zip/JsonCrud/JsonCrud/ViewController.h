//
//  ViewController.h
//  JsonCrud
//
//  Created by Tops on 12/18/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UrlClass.h"
@interface ViewController : UIViewController<UrlProtocole,UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate>
{
    UrlClass *urlclass;
    NSArray *arr_st;
    UIPickerView *pkr_st;
    
    NSArray *arr_ct;
    UIPickerView *pkr_ct;
}
@property (weak, nonatomic) IBOutlet UITextField *txt_state;
@property (weak, nonatomic) IBOutlet UITextField *txt_city;
@end

