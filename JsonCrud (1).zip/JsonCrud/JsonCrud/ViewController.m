//
//  ViewController.m
//  JsonCrud
//
//  Created by Tops on 12/18/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize txt_state,txt_city;
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    arr_st=[[NSArray alloc]init];
    arr_ct=[[NSArray alloc]init];
    
    pkr_st=[[UIPickerView alloc]init];
    pkr_st.dataSource=self;
    pkr_st.delegate=self;
    [txt_state setInputView:pkr_st];
    
    txt_city.delegate=self;
    pkr_ct=[[UIPickerView alloc]init];
    pkr_ct.dataSource=self;
    pkr_ct.delegate=self;
    [txt_city setInputView:pkr_ct];
    
    urlclass=[[UrlClass alloc]init];
    urlclass.delegate = self;
    [urlclass ConnectWithUrl:@"http://ios8192014.somee.com/webservice.asmx/JsonCrud1GetAllStates" Flag:@"state"];
}
-(void)GetUrlData:(NSArray *)arr_get Flag:(NSString *)st_flag
{
    if ([st_flag isEqual:@"state"])
    {
        arr_st=arr_get;
        [pkr_st reloadAllComponents];
    }
    else if ([st_flag isEqual:@"city"])
    {
        arr_ct=arr_get;
        [pkr_ct reloadAllComponents];
    }
   
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (pickerView==pkr_st)
    {
        return arr_st.count;
    }
    else
    {
        return arr_ct.count;
    }
    
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (pickerView==pkr_st)
    {
        return [[arr_st objectAtIndex:row]objectForKey:@"state_nm"];
    }
    else
    {
        return [[arr_ct objectAtIndex:row]objectForKey:@"city_nm"];
    }
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if (pickerView==pkr_st)
    {
    txt_state.text=[[arr_st objectAtIndex:row]objectForKey:@"state_nm"];
    }
    else
    {
        txt_city.text=[[arr_ct objectAtIndex:row]objectForKey:@"city_nm"];
    }
}
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (txt_state.text.length>0)
    {
        NSArray *arrkeyst=[arr_st valueForKey:@"state_nm"];
        
        NSInteger index=[arrkeyst indexOfObject:txt_state.text];
        
        NSString *orginal_id=[[arr_st objectAtIndex:index]objectForKey:@"state_id"];
        
        
        NSString *st_format=[NSString stringWithFormat:@"http://ios8192014.somee.com/webservice.asmx/JsonCrud2GetCityByState?state_id=%@",orginal_id];
        
        [urlclass ConnectWithUrl:st_format Flag:@"city"];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
