//
//  UrlClass.h
//  JsonCrud
//
//  Created by Tops on 12/18/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol UrlProtocole <NSObject>

@required

@optional
-(void)GetUrlData:(NSArray *)arr_get Flag:(NSString *)st_flag;
@end

@interface UrlClass : NSObject<NSURLConnectionDelegate,UrlProtocole>
{
    NSMutableData *datamute;
    NSString *global_flag;
}
@property(retain,nonatomic)id delegate;
-(void)ConnectWithUrl:(NSString *)st_url Flag:(NSString *)st_flag;
@end
