//
//  UrlClass.m
//  JsonCrud
//
//  Created by Tops on 12/18/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import "UrlClass.h"

@implementation UrlClass
@synthesize delegate;
-(void)ConnectWithUrl:(NSString *)st_url Flag:(NSString *)st_flag
{
    global_flag=st_flag;
    NSURL *url=[NSURL URLWithString:st_url];
    NSURLRequest *request=[NSURLRequest requestWithURL:url];
    NSURLConnection *con=[NSURLConnection connectionWithRequest:request delegate:self];
    if (con)
    {
        datamute=[[NSMutableData alloc]init];
    }
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    datamute.length=0;
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [datamute appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView *alrt=[[UIAlertView alloc]initWithTitle:@"Error" message:[error description] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    [alrt show];
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    //NSString *str=[[NSString alloc]initWithData:datamute encoding:NSUTF8StringEncoding];
    //NSLog(@"%@",str);
    if ([delegate respondsToSelector:@selector(GetUrlData:Flag:)])
    {
        NSArray *arr=[NSJSONSerialization JSONObjectWithData:datamute options:kNilOptions error:nil];
        [delegate GetUrlData:arr Flag:global_flag];
    }
    
    
}

@end
