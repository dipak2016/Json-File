//
//  DetailViewController.h
//  JsonCrudBasic
//
//  Created by Tops on 12/23/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UrlClass.h"

@interface DetailViewController : UIViewController<UrlProtocol>
{
    UrlClass *uclass;
}
@property(retain,nonatomic)NSString *st_vw_detail;
@property (weak, nonatomic) IBOutlet UIImageView *img_vw;
@property (weak, nonatomic) IBOutlet UILabel *lbl_fnm;
@property (weak, nonatomic) IBOutlet UILabel *lbl_lnm;
@property (weak, nonatomic) IBOutlet UILabel *lbl_st;
@property (weak, nonatomic) IBOutlet UILabel *lbl_ct;
@property (weak, nonatomic) IBOutlet UILabel *lb_unm;
@property (weak, nonatomic) IBOutlet UILabel *lbl_pass;

@end
