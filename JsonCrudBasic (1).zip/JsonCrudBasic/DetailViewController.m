//
//  DetailViewController.m
//  JsonCrudBasic
//
//  Created by Tops on 12/23/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController
@synthesize img_vw,lbl_fnm,lbl_lnm,lbl_st,lbl_ct,lbl_pass,st_vw_detail,lb_unm;

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    uclass=[[UrlClass alloc]init];
    uclass.delegate=self;
    NSString *st_format=[NSString stringWithFormat:@"http://ios8192014.somee.com/webservice.asmx/JsonCrud5GetUserDataByID?u_id=%@",st_vw_detail];
    [uclass ConntectWithURL:st_format Flag:@"detail"];
}
-(void)GetUrlData:(NSArray *)arrget Flag:(NSString *)stflag;
{
    if ([stflag isEqual:@"detail"])
    {
        lbl_fnm.text=[[arrget objectAtIndex:0]objectForKey:@"u_fnm"];
        lbl_lnm.text=[[arrget objectAtIndex:0]objectForKey:@"u_lnm"];
        lbl_st.text=[[arrget objectAtIndex:0]objectForKey:@"state_nm"];
        lbl_ct.text=[[arrget objectAtIndex:0]objectForKey:@"city_nm"];
        lb_unm.text=[[arrget objectAtIndex:0]objectForKey:@"u_unm"];
        lbl_pass.text=[[arrget objectAtIndex:0]objectForKey:@"u_pass"];
        
        NSURL *rul=[NSURL URLWithString:[[arrget objectAtIndex:0]objectForKey:@"u_photo"]];
        
        NSData *data=[[NSData alloc]initWithContentsOfURL:rul];
        img_vw.image=[UIImage imageWithData:data];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
