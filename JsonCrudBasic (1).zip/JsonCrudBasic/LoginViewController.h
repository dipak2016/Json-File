//
//  LoginViewController.h
//  JsonCrudBasic
//
//  Created by Tops on 12/23/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UrlClass.h"
#import "DetailViewController.h"

@interface LoginViewController : UIViewController<UrlProtocol,UIAlertViewDelegate>
{
    UrlClass *uclass;
}
@property (weak, nonatomic) IBOutlet UITextField *txt_unm;
@property (weak, nonatomic) IBOutlet UITextField *txt_upass;
- (IBAction)btn_login:(id)sender;

@end
