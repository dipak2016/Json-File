//
//  LoginViewController.m
//  JsonCrudBasic
//
//  Created by Tops on 12/23/15.
//  Copyright (c) 2015 Tops. All rights reserved.
//

#import "LoginViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController
@synthesize txt_unm,txt_upass;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    uclass=[[UrlClass alloc]init];
    uclass.delegate=self;
    
}
-(void)GetUrlData:(NSArray *)arrget Flag:(NSString *)stflag;
{
    if ([stflag isEqual:@"login"])
    {
        if ([[arrget objectAtIndex:0]intValue]>0)
        {
            DetailViewController *detail=[self.storyboard instantiateViewControllerWithIdentifier:@"DetailViewController"];
            detail.st_vw_detail=[arrget objectAtIndex:0];
            [self.navigationController pushViewController:detail animated:YES];
        }
        else
        {
            UIAlertView *alrt=[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Failed.." delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alrt show];
        }
    }
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    txt_unm.text=@"";
    txt_upass.text=@"";
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btn_login:(id)sender
{
    NSString *st_format=[NSString stringWithFormat:@"http://ios8192014.somee.com/webservice.asmx/JsonCrud4CheckLogin?u_nm=%@&u_pass=%@",txt_unm.text,txt_upass.text];
    [uclass ConntectWithURL:st_format Flag:@"login"];
}
@end
