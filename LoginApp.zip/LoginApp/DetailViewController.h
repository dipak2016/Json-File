//
//  DetailViewController.h
//  LoginApp
//
//  Created by Yosemite on 4/8/16.
//  Copyright (c) 2016 Yosemite. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController<NSURLConnectionDelegate>
{
    NSMutableData *datamute;
}
@property(retain,nonatomic)NSString *unm;
@property(retain,nonatomic)NSString *upass;
@end
