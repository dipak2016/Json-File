//
//  DetailViewController.m
//  LoginApp
//
//  Created by Yosemite on 4/8/16.
//  Copyright (c) 2016 Yosemite. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController
@synthesize unm,upass;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.view endEditing:YES];
    NSString *sturl=[NSString stringWithFormat:@"http://localhost/logintest/select.php"];
    NSURL *url=[NSURL URLWithString:sturl];
    NSString *stbody=[NSString stringWithFormat:@"e_unm=%@&e_upass=%@",unm,upass];
    NSMutableURLRequest *req=[[NSMutableURLRequest alloc]initWithURL:url];
    
    [req setHTTPBody:[stbody dataUsingEncoding:NSUTF8StringEncoding]];
    [req setHTTPMethod:@"POST"];
    
    NSURLConnection *con=[NSURLConnection connectionWithRequest:req delegate:self];
    if (con)
    {
        datamute=[[NSMutableData alloc]init];
    }
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    datamute.length=0;
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"%@",[error description]);
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [datamute appendData:data];
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    
    NSArray *arr=[NSJSONSerialization JSONObjectWithData:datamute options:kNilOptions error:nil];
    NSLog(@"%@",arr);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
