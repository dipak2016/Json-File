//
//  ViewController.h
//  LoginApp
//
//  Created by Yosemite on 4/8/16.
//  Copyright (c) 2016 Yosemite. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<NSURLConnectionDelegate>
{
    NSMutableData *datamute;
}
@property (weak, nonatomic) IBOutlet UITextField *txt_mn;
@property (weak, nonatomic) IBOutlet UITextField *txt_ct;
@property (weak, nonatomic) IBOutlet UITextField *txt_unm;
@property (weak, nonatomic) IBOutlet UITextField *txt_upass;
- (IBAction)btn_go:(id)sender;


@end

