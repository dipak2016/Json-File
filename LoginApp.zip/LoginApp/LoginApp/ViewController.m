//
//  ViewController.m
//  LoginApp
//
//  Created by Yosemite on 4/8/16.
//  Copyright (c) 2016 Yosemite. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize txt_ct,txt_mn,txt_unm,txt_upass;
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btn_go:(id)sender
{
    [self.view endEditing:YES];
    NSString *sturl=[NSString stringWithFormat:@"http://localhost/logintest/insertdata.php"];
    NSURL *url=[NSURL URLWithString:sturl];
    NSString *stbody=[NSString stringWithFormat:@"e_nm=%@&e_ct=%@&e_unm=%@&e_upass=%@",txt_mn.text,txt_ct.text,txt_unm.text,txt_upass.text];
    NSMutableURLRequest *req=[[NSMutableURLRequest alloc]initWithURL:url];
    
    [req setHTTPBody:[stbody dataUsingEncoding:NSUTF8StringEncoding]];
    [req setHTTPMethod:@"POST"];
    
    NSURLConnection *con=[NSURLConnection connectionWithRequest:req delegate:self];
    if (con)
    {
        datamute=[[NSMutableData alloc]init];
    }
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    datamute.length=0;
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"%@",[error description]);
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [datamute appendData:data];
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:datamute options:kNilOptions error:nil];
    UIAlertView *alrt=[[UIAlertView alloc]initWithTitle:@"Alert" message:[dict objectForKey:@"msg"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    [alrt show];
}
@end
