//
//  LoginViewController.h
//  LoginApp
//
//  Created by Yosemite on 4/8/16.
//  Copyright (c) 2016 Yosemite. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailViewController.h"
@interface LoginViewController : UIViewController<NSURLConnectionDelegate>
{
    NSMutableData *datamute;
}
@property (weak, nonatomic) IBOutlet UITextField *txt_unm;
@property (weak, nonatomic) IBOutlet UITextField *txt_upass;
- (IBAction)btn_login_action:(id)sender;


@end
