//
//  LoginViewController.m
//  LoginApp
//
//  Created by Yosemite on 4/8/16.
//  Copyright (c) 2016 Yosemite. All rights reserved.
//

#import "LoginViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController
@synthesize txt_unm,txt_upass;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btn_login_action:(id)sender
{
    [self.view endEditing:YES];
    NSString *sturl=[NSString stringWithFormat:@"http://localhost/logintest/login.php"];
    NSURL *url=[NSURL URLWithString:sturl];
    NSString *stbody=[NSString stringWithFormat:@"e_unm=%@&e_upass=%@",txt_unm.text,txt_upass.text];
    NSMutableURLRequest *req=[[NSMutableURLRequest alloc]initWithURL:url];
    
    [req setHTTPBody:[stbody dataUsingEncoding:NSUTF8StringEncoding]];
    [req setHTTPMethod:@"POST"];
    
    NSURLConnection *con=[NSURLConnection connectionWithRequest:req delegate:self];
    if (con)
    {
        datamute=[[NSMutableData alloc]init];
    }
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    datamute.length=0;
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"%@",[error description]);
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [datamute appendData:data];
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    
    NSArray *arr=[NSJSONSerialization JSONObjectWithData:datamute options:kNilOptions error:nil];
    int count=[[[[arr objectAtIndex:0]allValues]objectAtIndex:0]intValue];
    if (count==1)
    {
        DetailViewController *detal=[self.storyboard instantiateViewControllerWithIdentifier:@"DetailViewController"];
        detal.unm=txt_unm.text;
        detal.upass=txt_upass.text;
        
        [self.navigationController pushViewController:detal animated:YES];
    }
    else
    {
    UIAlertView *alrt=[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Failed" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    [alrt show];
    }
}
@end
